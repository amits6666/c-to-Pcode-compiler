#include <stdio.h>

void main() {
	int a;
	a = 2;
	a -= 7;
	return;
}