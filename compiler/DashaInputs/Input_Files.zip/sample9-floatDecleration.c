#include <stdio.h>

void main() {
	float a;
	a = 5.00;
	return;
}