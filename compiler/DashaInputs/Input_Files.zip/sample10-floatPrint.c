#include <stdio.h>

void main() {
	float a;

	a = 5.5;
	printf("%f\n", a);
}